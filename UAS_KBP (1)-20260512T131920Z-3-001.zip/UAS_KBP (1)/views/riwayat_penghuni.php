<?php
require_once '../koneksi.php';

$stmt = $koneksi->query(
    "SELECT
        r.*,
        k.nomor_kamar,
        k.kelas
     FROM riwayat_penghuni r
     JOIN kamar k ON r.id_kamar = k.id_kamar
     ORDER BY r.tanggal_keluar DESC"
);
$riwayat = $stmt->fetch_all(MYSQLI_ASSOC);

$total_hari = 0;
foreach ($riwayat as $r) {
    $masuk  = new DateTime($r['tanggal_masuk']);
    $keluar = new DateTime($r['tanggal_keluar']);
    $total_hari += $masuk->diff($keluar)->days;
}
$rata_hari = count($riwayat) > 0 ? round($total_hari / count($riwayat)) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Penghuni — Sistem Kost</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .card-glass {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.9);
        }
        .sidebar-item:hover  { background: rgba(255,255,255,0.15); }
        .sidebar-item.active { background: rgba(255,255,255,0.25); }
        .modal-overlay {
            display: none;
            position: fixed; inset: 0;
            background: rgba(15,23,42,0.4);
            backdrop-filter: blur(4px);
            z-index: 50;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.open { display: flex; }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(24px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .modal-box { animation: slideUp 0.3s ease; }
    </style>
</head>
<body class="bg-slate-100 min-h-screen">

<div class="flex min-h-screen">

    <!-- ===== SIDEBAR ===== -->
    <aside class="w-20 lg:w-64 min-h-screen flex-shrink-0"
           style="background:linear-gradient(160deg,#0d9488 0%,#0f766e 50%,#134e4a 100%);">
        <div class="p-5 flex items-center gap-3 border-b border-white/10">
            <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                </svg>
            </div>
            <span class="hidden lg:block text-white font-bold text-lg tracking-tight">SistemKost</span>
        </div>
        <nav class="p-3 space-y-1 mt-2">
            <a href="dashboard.php"
               class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                </svg>
                <span class="hidden lg:block text-sm">Dashboard</span>
            </a>
            <a href="kelola_kamar.php"
               class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                </svg>
                <span class="hidden lg:block text-sm">Kelola Kamar</span>
            </a>
            <a href="riwayat_penghuni.php"
               class="sidebar-item active flex items-center gap-3 px-3 py-3 rounded-xl text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                </svg>
                <span class="hidden lg:block text-sm font-semibold">Riwayat Penghuni</span>
            </a>
        </nav>
    </aside>

    <!-- ===== MAIN ===== -->
    <main class="flex-1 p-6 lg:p-8 overflow-auto">

        <!-- Header -->
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-2xl font-bold text-slate-800">Riwayat Penghuni</h1>
                <p class="text-slate-500 text-sm mt-0.5">Data penghuni yang sudah keluar / checkout</p>
            </div>
        </div>

        <!-- Stat mini -->
        <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div class="card-glass rounded-2xl p-5 shadow-sm">
                <p class="text-slate-400 text-xs font-medium mb-1">Total Mantan Penghuni</p>
                <p class="text-3xl font-bold text-slate-800"><?= count($riwayat) ?></p>
            </div>
            <div class="card-glass rounded-2xl p-5 shadow-sm">
                <p class="text-slate-400 text-xs font-medium mb-1">Rata-rata Lama Tinggal</p>
                <p class="text-3xl font-bold text-slate-800"><?= $rata_hari ?> <span class="text-base font-normal text-slate-400">hari</span></p>
            </div>
            <div class="card-glass rounded-2xl p-5 shadow-sm col-span-2 lg:col-span-1">
                <p class="text-slate-400 text-xs font-medium mb-1">Checkout Bulan Ini</p>
                <?php
                    $bulan_ini = array_filter($riwayat, function($r) {
                        return date('Y-m', strtotime($r['tanggal_keluar'])) === date('Y-m');
                    });
                ?>
                <p class="text-3xl font-bold text-slate-800"><?= count($bulan_ini) ?> <span class="text-base font-normal text-slate-400">orang</span></p>
            </div>
        </div>

        <!-- Tabel Riwayat -->
        <div class="card-glass rounded-2xl shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <div class="w-2 h-2 rounded-full bg-slate-400"></div>
                <h2 class="font-semibold text-slate-700 text-sm">Semua Riwayat</h2>
                <span class="ml-auto text-xs bg-slate-100 text-slate-500 font-semibold px-2 py-0.5 rounded-full">
                    <?= count($riwayat) ?> data
                </span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                            <th class="px-6 py-3 text-left">No. Kamar</th>
                            <th class="px-6 py-3 text-left">Kelas</th>
                            <th class="px-6 py-3 text-left">Nama Penghuni</th>
                            <th class="px-6 py-3 text-left">No. HP</th>
                            <th class="px-6 py-3 text-left">Tanggal Masuk</th>
                            <th class="px-6 py-3 text-left">Tanggal Keluar</th>
                            <th class="px-6 py-3 text-left">Lama Tinggal</th>
                            <th class="px-6 py-3 text-left">Detail</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                    <?php if (empty($riwayat)): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-12 text-center text-slate-400 text-sm">
                                <svg class="w-12 h-12 mx-auto mb-3 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                                </svg>
                                Belum ada riwayat penghuni
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($riwayat as $r):
                            $masuk    = new DateTime($r['tanggal_masuk']);
                            $keluar   = new DateTime($r['tanggal_keluar']);
                            $lama     = $masuk->diff($keluar)->days;
                        ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="px-6 py-4 font-bold text-slate-700">
                                <?= htmlspecialchars($r['nomor_kamar']) ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php if ($r['kelas'] === 'premium'): ?>
                                    <span class="text-xs font-semibold bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full">Premium</span>
                                <?php else: ?>
                                    <span class="text-xs font-semibold bg-violet-100 text-violet-600 px-2 py-0.5 rounded-full">Eksekutif</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 font-medium text-slate-700">
                                <?= htmlspecialchars($r['nama_lengkap']) ?>
                            </td>
                            <td class="px-6 py-4 text-slate-500">
                                <?= htmlspecialchars($r['nomor_hp']) ?>
                            </td>
                            <td class="px-6 py-4 text-slate-500">
                                <?= date('d M Y', strtotime($r['tanggal_masuk'])) ?>
                            </td>
                            <td class="px-6 py-4 text-slate-500">
                                <?= date('d M Y', strtotime($r['tanggal_keluar'])) ?>
                            </td>
                            <td class="px-6 py-4">
                                <span class="text-xs font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                                    <?= $lama ?> hari
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <button onclick="bukaDetail(<?= htmlspecialchars(json_encode($r)) ?>)"
                                        class="text-xs px-3 py-1.5 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100 font-medium transition-colors">
                                    Lihat
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<div id="modalDetail" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-sm mx-4 p-6">
        <div class="flex items-center justify-between mb-5">
            <h3 class="font-bold text-slate-800 text-lg">Detail Penghuni</h3>
            <button onclick="document.getElementById('modalDetail').classList.remove('open')"
                    class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>
        <div class="space-y-3 text-sm" id="isiDetail"></div>
    </div>
</div>

<script>
function bukaDetail(data) {
    const baris = [
        ['Nama Lengkap',    data.nama_lengkap],
        ['NIK',             '****-****-****-' + String(data.nik).slice(-4)],
        ['No. HP',          data.nomor_hp],
        ['Alamat Asal',     data.alamat_asal],
        ['Plat Kendaraan',  data.plat_kendaraan || '-'],
        ['Tanggal Masuk',   data.tanggal_masuk],
        ['Tanggal Keluar',  data.tanggal_keluar],
    ];
    document.getElementById('isiDetail').innerHTML = baris.map(([label, val]) => `
        <div class="flex justify-between gap-4 py-2 border-b border-slate-50 last:border-0">
            <span class="text-slate-400 flex-shrink-0">${label}</span>
            <span class="text-slate-700 font-medium text-right">${val}</span>
        </div>
    `).join('');
    document.getElementById('modalDetail').classList.add('open');
}
</script>

</body>
</html>