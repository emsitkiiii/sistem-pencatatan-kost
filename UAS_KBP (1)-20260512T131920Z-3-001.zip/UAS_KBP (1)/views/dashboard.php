<?php
require_once '../koneksi.php';
require_once '../class/Dashboard.php';

$dashboard     = new Dashboard($koneksi);
$ringkasan     = $dashboard->getRingkasan();
$hampirHabis   = $dashboard->getKamarHampirHabis();
$terlambat     = $dashboard->getKamarTerlambat();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Sistem Kost</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { jakarta: ['Plus Jakarta Sans', 'sans-serif'] },
                    colors: {
                        teal:   { 50:'#f0fdfa',100:'#ccfbf1',400:'#2dd4bf',500:'#14b8a6',600:'#0d9488',700:'#0f766e' },
                        amber:  { 400:'#fbbf24',500:'#f59e0b' },
                        violet: { 400:'#a78bfa',500:'#8b5cf6',600:'#7c3aed' },
                        rose:   { 400:'#fb7185',500:'#f43f5e' },
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .card-glass {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.9);
        }
        .sidebar-item:hover { background: rgba(255,255,255,0.15); }
        .sidebar-item.active { background: rgba(255,255,255,0.25); }
        @keyframes fadeUp {
            from { opacity:0; transform:translateY(16px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .fade-up { animation: fadeUp 0.5s ease forwards; }
        .delay-1 { animation-delay: 0.1s; opacity:0; }
        .delay-2 { animation-delay: 0.2s; opacity:0; }
        .delay-3 { animation-delay: 0.3s; opacity:0; }
        .delay-4 { animation-delay: 0.4s; opacity:0; }
    </style>
</head>
<body class="bg-slate-100 min-h-screen">

<div class="flex min-h-screen">

    <!-- ===== SIDEBAR ===== -->
    <aside class="w-20 lg:w-64 min-h-screen flex-shrink-0"
           style="background: linear-gradient(160deg, #0d9488 0%, #0f766e 50%, #134e4a 100%);">
        <div class="p-5 flex items-center gap-3 border-b border-white/10">
            <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                </svg>
            </div>
            <span class="hidden lg:block text-white font-bold text-lg tracking-tight">SistemKost</span>
        </div>

        <nav class="p-3 space-y-1 mt-2">
            <a href="dashboard.php"
               class="sidebar-item active flex items-center gap-3 px-3 py-3 rounded-xl text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                </svg>
                <span class="hidden lg:block text-sm font-600">Dashboard</span>
            </a>
            <a href="kelola_kamar.php"
               class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                </svg>
                <span class="hidden lg:block text-sm">Kelola Kamar</span>
            </a>
            <a href="riwayat_penghuni.php"
               class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                </svg>
                <span class="hidden lg:block text-sm">Riwayat Penghuni</span>
            </a>
        </nav>
    </aside>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="flex-1 p-6 lg:p-8 overflow-auto">

        <!-- Header -->
        <div class="fade-up delay-1 flex items-center justify-between mb-8">
            <div>
                <h1 class="text-2xl font-bold text-slate-800">Dashboard</h1>
                <p class="text-slate-500 text-sm mt-0.5">
                    <?= date('l, d F Y') ?>
                </p>
            </div>
            <?php if ($ringkasan['hampir_habis'] > 0 || $ringkasan['terlambat'] > 0): ?>
            <div class="flex items-center gap-2 bg-rose-50 border border-rose-200 text-rose-600 px-4 py-2 rounded-xl text-sm font-medium">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                </svg>
                <?= $ringkasan['hampir_habis'] + $ringkasan['terlambat'] ?> perlu perhatian
            </div>
            <?php endif; ?>
        </div>

        <!-- ===== STAT CARDS ===== -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

            <!-- Total Kamar -->
            <div class="fade-up delay-1 card-glass rounded-2xl p-5 shadow-sm">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                     style="background:linear-gradient(135deg,#2dd4bf,#0d9488)">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16"/>
                    </svg>
                </div>
                <p class="text-slate-500 text-xs font-medium mb-1">Total Kamar</p>
                <p class="text-3xl font-bold text-slate-800"><?= $ringkasan['total'] ?></p>
            </div>

            <!-- Kamar Terisi -->
            <div class="fade-up delay-2 card-glass rounded-2xl p-5 shadow-sm">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                     style="background:linear-gradient(135deg,#a78bfa,#7c3aed)">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                </div>
                <p class="text-slate-500 text-xs font-medium mb-1">Terisi</p>
                <p class="text-3xl font-bold text-slate-800"><?= $ringkasan['terisi'] ?></p>
            </div>

            <!-- Kamar Kosong -->
            <div class="fade-up delay-3 card-glass rounded-2xl p-5 shadow-sm">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                     style="background:linear-gradient(135deg,#fbbf24,#f59e0b)">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                    </svg>
                </div>
                <p class="text-slate-500 text-xs font-medium mb-1">Kosong</p>
                <p class="text-3xl font-bold text-slate-800"><?= $ringkasan['kosong'] ?></p>
            </div>

            <!-- Hampir Habis -->
            <div class="fade-up delay-4 card-glass rounded-2xl p-5 shadow-sm">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                     style="background:linear-gradient(135deg,#fb7185,#f43f5e)">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <p class="text-slate-500 text-xs font-medium mb-1">Hampir Habis</p>
                <p class="text-3xl font-bold text-slate-800"><?= $ringkasan['hampir_habis'] ?></p>
            </div>

        </div>

        <!-- ===== PROGRESS HUNIAN ===== -->
        <div class="fade-up delay-2 card-glass rounded-2xl p-6 shadow-sm mb-6">
            <div class="flex items-center justify-between mb-3">
                <div>
                    <h2 class="font-semibold text-slate-700">Tingkat Hunian</h2>
                    <p class="text-slate-400 text-xs">Persentase kamar yang sedang terisi</p>
                </div>
                <span class="text-2xl font-bold text-teal-600"><?= $ringkasan['persentase'] ?>%</span>
            </div>
            <div class="w-full bg-slate-100 rounded-full h-3">
                <div class="h-3 rounded-full transition-all duration-700"
                     style="width:<?= $ringkasan['persentase'] ?>%;
                            background:linear-gradient(90deg,#2dd4bf,#0d9488)">
                </div>
            </div>
            <div class="flex justify-between text-xs text-slate-400 mt-2">
                <span><?= $ringkasan['terisi'] ?> terisi</span>
                <span><?= $ringkasan['kosong'] ?> kosong</span>
            </div>
        </div>

        <!-- ===== NOTIFIKASI & TERLAMBAT ===== -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <!-- Sewa Hampir Habis -->
            <div class="fade-up delay-3 card-glass rounded-2xl shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full bg-amber-400"></div>
                    <h2 class="font-semibold text-slate-700 text-sm">Sewa Hampir Habis</h2>
                    <span class="ml-auto text-xs bg-amber-100 text-amber-600 font-semibold px-2 py-0.5 rounded-full">
                        ≤ 7 hari
                    </span>
                </div>
                <div class="divide-y divide-slate-50">
                    <?php if (empty($hampirHabis)): ?>
                        <div class="px-6 py-8 text-center text-slate-400 text-sm">
                            <svg class="w-10 h-10 mx-auto mb-2 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            Semua sewa masih aman
                        </div>
                    <?php else: ?>
                        <?php foreach ($hampirHabis as $item): ?>
                        <div class="px-6 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div>
                                <p class="text-sm font-semibold text-slate-700">
                                    Kamar <?= htmlspecialchars($item['nomor_kamar']) ?>
                                    <span class="text-xs font-normal text-slate-400 ml-1">
                                        (<?= ucfirst($item['kelas']) ?>)
                                    </span>
                                </p>
                                <p class="text-xs text-slate-400"><?= htmlspecialchars($item['nama_lengkap']) ?></p>
                            </div>
                            <div class="text-right">
                                <span class="text-xs font-bold <?= $item['sisa_hari'] <= 3 ? 'text-rose-500' : 'text-amber-500' ?>">
                                    <?= $item['sisa_hari'] ?> hari lagi
                                </span>
                                <p class="text-xs text-slate-400"><?= date('d M Y', strtotime($item['tanggal_habis'])) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sewa Terlambat -->
            <div class="fade-up delay-4 card-glass rounded-2xl shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full bg-rose-400"></div>
                    <h2 class="font-semibold text-slate-700 text-sm">Sewa Terlambat</h2>
                    <span class="ml-auto text-xs bg-rose-100 text-rose-600 font-semibold px-2 py-0.5 rounded-full">
                        Lewat jatuh tempo
                    </span>
                </div>
                <div class="divide-y divide-slate-50">
                    <?php if (empty($terlambat)): ?>
                        <div class="px-6 py-8 text-center text-slate-400 text-sm">
                            <svg class="w-10 h-10 mx-auto mb-2 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            Tidak ada keterlambatan
                        </div>
                    <?php else: ?>
                        <?php foreach ($terlambat as $item): ?>
                        <div class="px-6 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div>
                                <p class="text-sm font-semibold text-slate-700">
                                    Kamar <?= htmlspecialchars($item['nomor_kamar']) ?>
                                    <span class="text-xs font-normal text-slate-400 ml-1">
                                        (<?= ucfirst($item['kelas']) ?>)
                                    </span>
                                </p>
                                <p class="text-xs text-slate-400"><?= htmlspecialchars($item['nama_lengkap']) ?></p>
                            </div>
                            <div class="text-right">
                                <span class="text-xs font-bold text-rose-500">
                                    +<?= $item['hari_terlambat'] ?> hari
                                </span>
                                <p class="text-xs text-slate-400"><?= date('d M Y', strtotime($item['tanggal_habis'])) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>
        <!-- end grid -->

    </main>
    <!-- end main -->

</div>
<!-- end flex -->

</body>
</html>