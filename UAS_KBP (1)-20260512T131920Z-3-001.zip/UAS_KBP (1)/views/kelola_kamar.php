<?php
require_once '../koneksi.php';
require_once '../class/Kamar.php';

$kamar_list = Kamar::getAll($koneksi);

$kamar_kosong = array_filter($kamar_list, fn($k) => $k['status'] === 'kosong');
$kamar_terisi = array_filter($kamar_list, fn($k) => $k['status'] === 'terisi');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kamar — Sistem Kost</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .card-glass { background: rgba(255,255,255,0.7); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.9); }
        .sidebar-item:hover  { background: rgba(255,255,255,0.15); }
        .sidebar-item.active { background: rgba(255,255,255,0.25); }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.4); backdrop-filter: blur(4px); z-index: 50; align-items: center; justify-content: center; }
        .modal-overlay.open { display: flex; }
        @keyframes slideUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
        .modal-box { animation: slideUp 0.3s ease; }
        input:focus, select:focus, textarea:focus { outline: none; border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13,148,136,0.15); }
    </style>
</head>
<body class="bg-slate-100 min-h-screen">
<div class="flex min-h-screen">

    <!-- SIDEBAR -->
    <aside class="w-20 lg:w-64 min-h-screen flex-shrink-0" style="background:linear-gradient(160deg,#0d9488 0%,#0f766e 50%,#134e4a 100%);">
        <div class="p-5 flex items-center gap-3 border-b border-white/10">
            <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            </div>
            <span class="hidden lg:block text-white font-bold text-lg tracking-tight">SistemKost</span>
        </div>
        <nav class="p-3 space-y-1 mt-2">
            <a href="dashboard.php" class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                <span class="hidden lg:block text-sm">Dashboard</span>
            </a>
            <a href="kelola_kamar.php" class="sidebar-item active flex items-center gap-3 px-3 py-3 rounded-xl text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                <span class="hidden lg:block text-sm font-semibold">Kelola Kamar</span>
            </a>
            <a href="riwayat_penghuni.php" class="sidebar-item flex items-center gap-3 px-3 py-3 rounded-xl text-white/75 hover:text-white transition-all">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                <span class="hidden lg:block text-sm">Riwayat Penghuni</span>
            </a>
        </nav>
    </aside>

    <!-- MAIN -->
    <main class="flex-1 p-6 lg:p-8 overflow-auto">

        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-2xl font-bold text-slate-800">Kelola Kamar</h1>
                <p class="text-slate-500 text-sm mt-0.5">Daftar semua kamar dan data penghuni</p>
            </div>
            <button onclick="document.getElementById('modalTambahKamar').classList.add('open')"
                    class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white text-sm font-semibold shadow-md transition-all hover:opacity-90"
                    style="background:linear-gradient(135deg,#2dd4bf,#0d9488)">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Tambah Kamar
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="mb-4 px-4 py-3 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 text-sm font-medium flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <?php 
            $msg = [
                'kamar_ditambah'    => 'Kamar baru berhasil ditambahkan.',
                'kamar_diupdate'    => 'Data kamar berhasil diperbarui.',
                'kamar_dihapus'     => 'Kamar berhasil dihapus.',
                'penghuni_ditambah' => 'Data penghuni berhasil disimpan.',
                'diperpanjang'      => 'Sewa berhasil diperpanjang.',
                'checkout'          => 'Penghuni berhasil ditandai keluar.'
            ]; 
            echo $msg[$_GET['success']] ?? 'Berhasil.'; 
            ?>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
        <div class="mb-4 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-sm font-medium">
            <?= htmlspecialchars($_GET['error']) ?>
        </div>
        <?php endif; ?>

<!-- MODAL DETAIL PENGHUNI AKTIF -->
<div id="modalDetailPenghuni" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-sm mx-4 p-6">
        <div class="flex items-center justify-between mb-5">
            <h3 class="font-bold text-slate-800 text-lg">Detail Penghuni</h3>
            <button onclick="document.getElementById('modalDetailPenghuni').classList.remove('open')" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="space-y-3 text-sm" id="isiDetailPenghuni">
            
        </div>
    </div>
</div>

<!-- TABEL KAMAR TERISI -->
        <div class="card-glass rounded-2xl shadow-sm overflow-hidden mb-6">
            <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <div class="w-2 h-2 rounded-full bg-violet-400"></div>
                <h2 class="font-semibold text-slate-700 text-sm">Kamar Terisi</h2>
                <span class="ml-auto text-xs bg-violet-100 text-violet-600 font-semibold px-2 py-0.5 rounded-full"><?= count($kamar_terisi) ?> kamar</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                            <th class="px-6 py-3 text-left">No. Kamar</th>
                            <th class="px-6 py-3 text-left">Kelas</th>
                            <th class="px-6 py-3 text-left">Penghuni</th>
                            <th class="px-6 py-3 text-left">No. HP</th>
                            <th class="px-6 py-3 text-left">Sisa Sewa</th>
                            <th class="px-6 py-3 text-left">Habis Sewa</th>
                            <th class="px-6 py-3 text-left">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                    <?php if (empty($kamar_terisi)): ?>
                        <tr><td colspan="7" class="px-6 py-8 text-center text-slate-400 text-sm">Belum ada kamar yang terisi</td></tr>
                    <?php else: ?>
                        <?php foreach ($kamar_terisi as $kamar): ?>
                        <?php
                            $sewa = null;
                            $sisa_hari = '-';
                            $tgl_habis = '-';
                            $stmt = $koneksi->prepare(
                                "SELECT s.*, p.nama_lengkap, p.nomor_hp, p.nik, p.alamat_asal, p.plat_kendaraan
                                 FROM sewa s
                                 JOIN penghuni p ON s.id_sewa = p.id_sewa
                                 WHERE s.id_kamar = ? ORDER BY s.tanggal_masuk DESC LIMIT 1"
                            );
                            $stmt->bind_param('i', $kamar['id_kamar']);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $sewa   = $result->fetch_assoc();
                            if ($sewa) {
                                $diff      = (new DateTime())->diff(new DateTime($sewa['tanggal_habis']));
                                $sisa_hari = $sewa['tanggal_habis'] >= date('Y-m-d')
                                           ? $diff->days . ' hari'
                                           : '<span class="text-rose-500 font-semibold">Terlambat ' . $diff->days . ' hari</span>';
                                $tgl_habis = date('d M Y', strtotime($sewa['tanggal_habis']));
                            }
                            // Siapkan data sewa untuk JavaScript (hindari karakter bermasalah)
                            $sewa_json = $sewa ? htmlspecialchars(json_encode($sewa), ENT_QUOTES, 'UTF-8') : '{}';
                        ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="px-6 py-4 font-bold text-slate-700"><?= htmlspecialchars($kamar['nomor_kamar']) ?></td>
                            <td class="px-6 py-4">
                                <?php if ($kamar['kelas'] === 'premium'): ?>
                                    <span class="text-xs font-semibold bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full">Premium</span>
                                <?php else: ?>
                                    <span class="text-xs font-semibold bg-violet-100 text-violet-600 px-2 py-0.5 rounded-full">Eksekutif</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-slate-700">
                                <?php if ($sewa): ?>
                                    <button onclick='bukaDetailPenghuni(<?= $sewa_json ?>)' 
                                            class="text-slate-700 hover:text-teal-600 hover:underline font-medium transition-colors text-left">
                                        <?= htmlspecialchars($sewa['nama_lengkap']) ?>
                                    </button>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-slate-500"><?= $sewa ? htmlspecialchars($sewa['nomor_hp']) : '-' ?></td>
                            <td class="px-6 py-4"><?= $sisa_hari ?></td>
                            <td class="px-6 py-4 text-slate-500"><?= $tgl_habis ?></td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <button onclick="bukaModalPerpanjang(<?= $kamar['id_kamar'] ?>, '<?= htmlspecialchars($kamar['nomor_kamar']) ?>', <?= $sewa['id_sewa'] ?? 0 ?>)"
                                            class="text-xs px-3 py-1.5 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100 font-medium transition-colors">
                                        Perpanjang
                                    </button>
                                    <form method="POST" action="../action/proses_checkout.php"
                                          onsubmit="return confirm('Tandai penghuni kamar <?= htmlspecialchars($kamar['nomor_kamar']) ?> sudah keluar?')">
                                        <input type="hidden" name="id_kamar" value="<?= $kamar['id_kamar'] ?>">
                                        <input type="hidden" name="id_sewa"  value="<?= $sewa['id_sewa'] ?? 0 ?>">
                                        <button type="submit" class="text-xs px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 font-medium transition-colors">Keluar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TABEL KAMAR KOSONG -->
        <div class="card-glass rounded-2xl shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <div class="w-2 h-2 rounded-full bg-teal-400"></div>
                <h2 class="font-semibold text-slate-700 text-sm">Kamar Kosong</h2>
                <span class="ml-auto text-xs bg-teal-100 text-teal-600 font-semibold px-2 py-0.5 rounded-full"><?= count($kamar_kosong) ?> kamar</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                            <th class="px-6 py-3 text-left">No. Kamar</th>
                            <th class="px-6 py-3 text-left">Kelas</th>
                            <th class="px-6 py-3 text-left">Harga Sewa</th>
                            <th class="px-6 py-3 text-left">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                    <?php if (empty($kamar_kosong)): ?>
                        <tr><td colspan="4" class="px-6 py-8 text-center text-slate-400 text-sm">Tidak ada kamar kosong</td></tr>
                    <?php else: ?>
                        <?php foreach ($kamar_kosong as $kamar): ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="px-6 py-4 font-bold text-slate-700"><?= htmlspecialchars($kamar['nomor_kamar']) ?></td>
                            <td class="px-6 py-4">
                                <?php if ($kamar['kelas'] === 'premium'): ?>
                                    <span class="text-xs font-semibold bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full">Premium</span>
                                <?php else: ?>
                                    <span class="text-xs font-semibold bg-violet-100 text-violet-600 px-2 py-0.5 rounded-full">Eksekutif</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-slate-700">Rp <?= number_format($kamar['harga_sewa'], 0, ',', '.') ?></td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <button onclick="bukaModalPenghuni(<?= $kamar['id_kamar'] ?>, '<?= htmlspecialchars($kamar['nomor_kamar']) ?>')"
                                            class="text-xs px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 hover:bg-violet-100 font-medium transition-colors">
                                        + Isi
                                    </button>
                                    <button onclick="bukaModalEditKamar(<?= $kamar['id_kamar'] ?>, '<?= htmlspecialchars($kamar['nomor_kamar']) ?>', '<?= htmlspecialchars($kamar['kelas']) ?>', <?= $kamar['harga_sewa'] ?>)"
                                            class="text-xs px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 font-medium transition-colors">
                                        Edit
                                    </button>
                                    <form method="POST" action="../action/proses_hapus_kamar.php"
                                          onsubmit="return confirm('Hapus kamar <?= htmlspecialchars($kamar['nomor_kamar']) ?>? Data tidak bisa dikembalikan.')" class="inline">
                                        <input type="hidden" name="id_kamar" value="<?= $kamar['id_kamar'] ?>">
                                        <button type="submit" class="text-xs px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 font-medium transition-colors">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<!-- MODAL TAMBAH KAMAR -->
<div id="modalTambahKamar" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6">
        <div class="flex items-center justify-between mb-5">
            <h3 class="font-bold text-slate-800 text-lg">Tambah Kamar Baru</h3>
            <button onclick="document.getElementById('modalTambahKamar').classList.remove('open')" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form method="POST" action="../action/proses_tambah_kamar.php" class="space-y-4">
            <input type="hidden" name="aksi" value="tambah_kamar">
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Nomor Kamar</label>
                <input type="text" name="nomor_kamar" required placeholder="Contoh: 101" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 transition-all">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Kelas Kamar</label>
                <select name="kelas" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 transition-all bg-white">
                    <option value="">-- Pilih Kelas --</option>
                    <option value="premium">Premium</option>
                    <option value="eksekutif">Eksekutif</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Harga Sewa / Bulan</label>
                <div class="relative">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm">Rp</span>
                    <input type="number" name="harga_sewa" required placeholder="500000" min="0" class="w-full border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-700 transition-all">
                </div>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="document.getElementById('modalTambahKamar').classList.remove('open')" class="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">Batal</button>
                <button type="submit" class="flex-1 py-2.5 rounded-xl text-white text-sm font-semibold hover:opacity-90" style="background:linear-gradient(135deg,#2dd4bf,#0d9488)">Simpan Kamar</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL ISI PENGHUNI -->
<div id="modalPenghuni" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-lg mx-4 p-6 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between mb-5">
            <div>
                <h3 class="font-bold text-slate-800 text-lg">Data Penghuni Baru</h3>
                <p class="text-slate-400 text-xs mt-0.5">Kamar <span id="labelNomorKamar" class="font-semibold text-teal-600"></span></p>
            </div>
            <button onclick="document.getElementById('modalPenghuni').classList.remove('open')" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form method="POST" action="../action/proses_tambah_kamar.php" class="space-y-4">
            <input type="hidden" name="aksi"     value="isi_penghuni">
            <input type="hidden" name="id_kamar" id="inputIdKamar">
            <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Data Pribadi</p>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" required placeholder="Nama sesuai KTP" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">NIK (16 digit)</label>
                <input type="text" name="nik" required maxlength="16" placeholder="3271XXXXXXXXXXXX" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1.5">Nomor HP</label>
                    <input type="text" name="nomor_hp" required placeholder="08xxxxxxxxxx" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1.5">Plat Kendaraan</label>
                    <input type="text" name="plat_kendaraan" placeholder="AB 1234 CD" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700">
                </div>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Alamat Asal</label>
                <textarea name="alamat_asal" rows="2" required placeholder="Jl. Contoh No. 1, Kota" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 resize-none"></textarea>
            </div>
            <p class="text-xs font-bold text-slate-400 uppercase tracking-widest pt-1">Data Sewa</p>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1.5">Tanggal Masuk</label>
                    <input type="date" name="tanggal_masuk" id="inputTanggalMasuk" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-600 mb-1.5">Durasi Sewa</label>
                    <select name="durasi_bulan" id="inputDurasi" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 bg-white">
                        <option value="">-- Pilih --</option>
                        <option value="3">3 Bulan</option>
                        <option value="6">6 Bulan</option>
                        <option value="12">12 Bulan (1 Tahun)</option>
                    </select>
                </div>
            </div>
            <div id="previewHabis" class="hidden px-4 py-3 rounded-xl bg-teal-50 border border-teal-100 text-sm text-teal-700">
                Tanggal habis sewa: <span id="textTanggalHabis" class="font-bold"></span>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="document.getElementById('modalPenghuni').classList.remove('open')" class="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">Batal</button>
                <button type="submit" class="flex-1 py-2.5 rounded-xl text-white text-sm font-semibold hover:opacity-90" style="background:linear-gradient(135deg,#2dd4bf,#0d9488)">Simpan Penghuni</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL PERPANJANG -->
<div id="modalPerpanjang" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-sm mx-4 p-6">
        <div class="flex items-center justify-between mb-5">
            <div>
                <h3 class="font-bold text-slate-800 text-lg">Perpanjang Sewa</h3>
                <p class="text-slate-400 text-xs mt-0.5">Kamar <span id="labelNomorKamarPerpanjang" class="font-semibold text-teal-600"></span></p>
            </div>
            <button onclick="document.getElementById('modalPerpanjang').classList.remove('open')" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form method="POST" action="../action/proses_perpanjang.php" class="space-y-4">
            <input type="hidden" name="id_kamar" id="perpanjangIdKamar">
            <input type="hidden" name="id_sewa"  id="perpanjangIdSewa">
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Tambah Durasi</label>
                <select name="tambahan_bulan" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 bg-white">
                    <option value="">-- Pilih --</option>
                    <option value="3">+ 3 Bulan</option>
                    <option value="6">+ 6 Bulan</option>
                    <option value="12">+ 12 Bulan</option>
                </select>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="document.getElementById('modalPerpanjang').classList.remove('open')" class="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium">Batal</button>
                <button type="submit" class="flex-1 py-2.5 rounded-xl text-white text-sm font-semibold hover:opacity-90" style="background:linear-gradient(135deg,#2dd4bf,#0d9488)">Perpanjang</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL EDIT KAMAR -->
<div id="modalEditKamar" class="modal-overlay">
    <div class="modal-box bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6">
        <div class="flex items-center justify-between mb-5">
            <h3 class="font-bold text-slate-800 text-lg">Edit Data Kamar</h3>
            <button onclick="document.getElementById('modalEditKamar').classList.remove('open')" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center">
                <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form method="POST" action="../action/proses_edit_kamar.php" class="space-y-4">
            <input type="hidden" name="id_kamar" id="editIdKamar">
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Nomor Kamar</label>
                <input type="text" name="nomor_kamar" id="editNomorKamar" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 transition-all">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Kelas Kamar</label>
                <select name="kelas" id="editKelas" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 transition-all bg-white">
                    <option value="">-- Pilih Kelas --</option>
                    <option value="premium">Premium</option>
                    <option value="eksekutif">Eksekutif</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1.5">Harga Sewa / Bulan</label>
                <div class="relative">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm">Rp</span>
                    <input type="number" name="harga_sewa" id="editHargaSewa" required min="0" class="w-full border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-700 transition-all">
                </div>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="document.getElementById('modalEditKamar').classList.remove('open')" class="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">Batal</button>
                <button type="submit" class="flex-1 py-2.5 rounded-xl text-white text-sm font-semibold hover:opacity-90" style="background:linear-gradient(135deg,#f59e0b,#d97706)">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script>
function bukaModalPenghuni(idKamar, nomorKamar) {
    document.getElementById('inputIdKamar').value = idKamar;
    document.getElementById('labelNomorKamar').textContent = nomorKamar;
    document.getElementById('modalPenghuni').classList.add('open');
}

function bukaModalPerpanjang(idKamar, nomorKamar, idSewa) {
    document.getElementById('perpanjangIdKamar').value = idKamar;
    document.getElementById('perpanjangIdSewa').value = idSewa;
    document.getElementById('labelNomorKamarPerpanjang').textContent = nomorKamar;
    document.getElementById('modalPerpanjang').classList.add('open');
}

function bukaModalEditKamar(idKamar, nomorKamar, kelas, hargaSewa) {
    document.getElementById('editIdKamar').value = idKamar;
    document.getElementById('editNomorKamar').value = nomorKamar;
    document.getElementById('editKelas').value = kelas;
    document.getElementById('editHargaSewa').value = hargaSewa;
    document.getElementById('modalEditKamar').classList.add('open');
}

function bukaDetailPenghuni(data) {
    var nikSensor = data.nik ? '****' + String(data.nik).slice(-4) : '-';
    var baris = [
        ['Nama Lengkap',   data.nama_lengkap || '-'],
        ['NIK',            nikSensor],
        ['No. HP',         data.nomor_hp || '-'],
        ['Alamat Asal',    data.alamat_asal || '-'],
        ['Plat Kendaraan', data.plat_kendaraan || '-'],
        ['Tanggal Masuk',  data.tanggal_masuk || '-'],
        ['Tanggal Habis',  data.tanggal_habis || '-'],
        ['Durasi Sewa',    (data.durasi_bulan || 0) + ' bulan']
    ];
    
    var html = '';
    for (var i = 0; i < baris.length; i++) {
        html += '<div class="flex justify-between gap-4 py-2 border-b border-slate-50 last:border-0">' +
                '<span class="text-slate-400 flex-shrink-0">' + baris[i][0] + '</span>' +
                '<span class="text-slate-700 font-medium text-right">' + baris[i][1] + '</span>' +
                '</div>';
    }
    
    document.getElementById('isiDetailPenghuni').innerHTML = html;
    document.getElementById('modalDetailPenghuni').classList.add('open');
}

function hitungTanggalHabis() {
    const tgl = document.getElementById('inputTanggalMasuk').value;
    const durasi = parseInt(document.getElementById('inputDurasi').value);
    if (!tgl || !durasi) {
        document.getElementById('previewHabis').classList.add('hidden');
        return;
    }
    const tglMasuk = new Date(tgl);
    tglMasuk.setMonth(tglMasuk.getMonth() + durasi);
    const hasil = tglMasuk.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    document.getElementById('textTanggalHabis').textContent = hasil;
    document.getElementById('previewHabis').classList.remove('hidden');
}

if (document.getElementById('inputTanggalMasuk')) {
    document.getElementById('inputTanggalMasuk').value = new Date().toISOString().split('T')[0];
}

if (document.getElementById('inputTanggalMasuk')) {
    document.getElementById('inputTanggalMasuk').addEventListener('change', hitungTanggalHabis);
}
if (document.getElementById('inputDurasi')) {
    document.getElementById('inputDurasi').addEventListener('change', hitungTanggalHabis);
}
</script>