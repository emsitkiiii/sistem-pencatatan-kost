<?php

class Dashboard {

    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }

    public function getTotalKamar() {
        $result = $this->koneksi->query("SELECT COUNT(*) AS total FROM kamar");
        $row = $result->fetch_assoc();
        return (int) $row['total'];
    }

    public function getJumlahKosong() {
        $result = $this->koneksi->query("SELECT COUNT(*) AS total FROM kamar WHERE status = 'kosong'");
        $row = $result->fetch_assoc();
        return (int) $row['total'];
    }

    public function getJumlahTerisi() {
        $result = $this->koneksi->query("SELECT COUNT(*) AS total FROM kamar WHERE status = 'terisi'");
        $row = $result->fetch_assoc();
        return (int) $row['total'];
    }

    public function getPersentaseHunian() {
        $total = $this->getTotalKamar();
        if ($total == 0) return 0;
        return round(($this->getJumlahTerisi() / $total) * 100);
    }

    public function getKamarHampirHabis() {
        $sql = "SELECT k.id_kamar, k.nomor_kamar, k.kelas,
                       p.nama_lengkap, p.nomor_hp, s.tanggal_habis,
                       DATEDIFF(s.tanggal_habis, CURDATE()) AS sisa_hari
                FROM kamar k
                JOIN sewa s ON k.id_kamar = s.id_kamar
                JOIN penghuni p ON s.id_sewa = p.id_sewa
                WHERE s.tanggal_habis BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                AND k.status = 'terisi'
                ORDER BY s.tanggal_habis ASC";
        $result = $this->koneksi->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getJumlahHampirHabis() {
        return count($this->getKamarHampirHabis());
    }

    public function getKamarTerlambat() {
        $sql = "SELECT k.id_kamar, k.nomor_kamar, k.kelas,
                       p.nama_lengkap, p.nomor_hp, s.tanggal_habis,
                       DATEDIFF(CURDATE(), s.tanggal_habis) AS hari_terlambat
                FROM kamar k
                JOIN sewa s ON k.id_kamar = s.id_kamar
                JOIN penghuni p ON s.id_sewa = p.id_sewa
                WHERE s.tanggal_habis < CURDATE()
                AND k.status = 'terisi'
                ORDER BY s.tanggal_habis ASC";
        $result = $this->koneksi->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getRingkasan() {
        return [
            'total'        => $this->getTotalKamar(),
            'kosong'       => $this->getJumlahKosong(),
            'terisi'       => $this->getJumlahTerisi(),
            'persentase'   => $this->getPersentaseHunian(),
            'hampir_habis' => $this->getJumlahHampirHabis(),
            'terlambat'    => count($this->getKamarTerlambat()),
        ];
    }
}