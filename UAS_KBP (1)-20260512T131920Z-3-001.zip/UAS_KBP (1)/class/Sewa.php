<?php

class Sewa {

    private $id_sewa;
    private $id_kamar;
    private $tanggal_masuk;
    private $durasi_bulan;
    private $tanggal_habis;

    public function __construct($id_kamar, $tanggal_masuk, $durasi_bulan) {
        $this->id_kamar      = $id_kamar;
        $this->tanggal_masuk = new DateTime($tanggal_masuk);
        $this->setDurasi($durasi_bulan);
        $this->hitungTanggalHabis();
    }

    public function getIdSewa()      { return $this->id_sewa; }
    public function getIdKamar()     { return $this->id_kamar; }
    public function getDurasiBulan() { return $this->durasi_bulan; }

    public function getTanggalMasuk() {
        return $this->tanggal_masuk->format('Y-m-d');
    }

    public function getTanggalHabis() {
        return $this->tanggal_habis->format('Y-m-d');
    }

    public function setIdSewa($id_sewa) {
        $this->id_sewa = $id_sewa;
    }

    public function setDurasi($durasi_bulan) {
        $allowed = [3, 6, 12];
        if (in_array((int)$durasi_bulan, $allowed)) {
            $this->durasi_bulan = (int)$durasi_bulan;
        } else {
            throw new InvalidArgumentException("Durasi sewa harus 3, 6, atau 12 bulan.");
        }
    }

    private function hitungTanggalHabis() {
        $this->tanggal_habis = clone $this->tanggal_masuk;
        $this->tanggal_habis->modify("+{$this->durasi_bulan} months");
    }

    public function hitungSisaHari() {
        $hari_ini = new DateTime('today');
        $selisih  = $hari_ini->diff($this->tanggal_habis);
        if ($this->tanggal_habis < $hari_ini) {
            return -$selisih->days;
        }
        return $selisih->days;
    }

    public function akanHabisDalam7Hari() {
        $sisa = $this->hitungSisaHari();
        return $sisa >= 0 && $sisa <= 7;
    }

    public function simpan($koneksi) {
        $tgl_masuk = $this->getTanggalMasuk();
        $tgl_habis = $this->getTanggalHabis();

        $sql  = "INSERT INTO sewa (id_kamar, tanggal_masuk, durasi_bulan, tanggal_habis)
                 VALUES (?, ?, ?, ?)";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('isis',
            $this->id_kamar,
            $tgl_masuk,
            $this->durasi_bulan,
            $tgl_habis
        );
        $stmt->execute();
        $this->id_sewa = $koneksi->insert_id;
        return $this->id_sewa;
    }

    public function perpanjangSewa($koneksi, $tambahan_bulan) {
        $allowed = [3, 6, 12];
        if (!in_array((int)$tambahan_bulan, $allowed)) {
            throw new InvalidArgumentException("Tambahan durasi harus 3, 6, atau 12 bulan.");
        }

        $this->tanggal_habis->modify("+{$tambahan_bulan} months");
        $this->durasi_bulan += (int)$tambahan_bulan;
        $tgl_habis = $this->getTanggalHabis();

        $sql  = "UPDATE sewa SET tanggal_habis = ?, durasi_bulan = ? WHERE id_sewa = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('sii', $tgl_habis, $this->durasi_bulan, $this->id_sewa);
        return $stmt->execute();
    }

    public static function getByIdKamar($koneksi, $id_kamar) {
        $sql  = "SELECT * FROM sewa WHERE id_kamar = ? ORDER BY tanggal_masuk DESC LIMIT 1";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('i', $id_kamar);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public static function getHampirHabis($koneksi) {
        $sql  = "SELECT s.*, k.nomor_kamar, k.kelas
                 FROM sewa s
                 JOIN kamar k ON s.id_kamar = k.id_kamar
                 WHERE s.tanggal_habis BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                 ORDER BY s.tanggal_habis ASC";
        $result = $koneksi->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

}