<?php

require_once 'Kamar.php';

class KamarPremium extends Kamar {

    private $fasilitas = [
        'AC',
        'TV 24 inch',
        'Kasur standar',
        'Lemari pakaian',
        'Kamar mandi dalam'
    ];

    public function __construct($nomor_kamar, $harga_sewa) {
        parent::__construct($nomor_kamar, 'premium', $harga_sewa);
    }

    public function getFasilitas() {
        return implode(', ', $this->fasilitas);
    }

    public function getLabelKelas() {
        return '<span style="background:#F59E0B;color:#fff;padding:2px 8px;border-radius:4px;font-size:12px;">Premium</span>';
    }

}

class KamarEksekutif extends Kamar {

    private $fasilitas = [
        'AC',
        'Smart TV 32 inch',
        'Kasur King Size',
        'Lemari pakaian besar',
        'Kamar mandi dalam + water heater',
        'Kulkas',
        'Meja kerja'
    ];

    public function __construct($nomor_kamar, $harga_sewa) {
        parent::__construct($nomor_kamar, 'eksekutif', $harga_sewa);
    }

    public function getFasilitas() {
        return implode(', ', $this->fasilitas);
    }

    public function getLabelKelas() {
        return '<span style="background:#6D28D9;color:#fff;padding:2px 8px;border-radius:4px;font-size:12px;">Eksekutif</span>';
    }

}