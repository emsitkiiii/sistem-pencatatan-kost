<?php

class Kamar {

    protected $id_kamar;
    protected $nomor_kamar;
    protected $kelas;
    protected $status;
    protected $harga_sewa;

    private $nama_lengkap;
    private $nik;
    private $nomor_hp;
    private $alamat_asal;
    private $plat_kendaraan;

    public function __construct($nomor_kamar, $kelas, $harga_sewa) {
        $this->nomor_kamar = $nomor_kamar;
        $this->kelas       = $kelas;
        $this->harga_sewa  = $harga_sewa;
        $this->status      = 'kosong';
    }

    public function getIdKamar()    { return $this->id_kamar; }
    public function getNomorKamar() { return $this->nomor_kamar; }
    public function getKelas()      { return $this->kelas; }
    public function getStatus()     { return $this->status; }
    public function getHargaSewa()  { return $this->harga_sewa; }

    public function setStatus($status) {
        $allowed = ['kosong', 'terisi'];
        if (in_array($status, $allowed)) {
            $this->status = $status;
        }
    }

    public function getNamaLengkap()   { return $this->nama_lengkap; }
    public function getNomorHp()       { return $this->nomor_hp; }
    public function getAlamatAsal()    { return $this->alamat_asal; }
    public function getPlatKendaraan() { return $this->plat_kendaraan; }

    public function getNikSensor() {
        if (!$this->nik) return '-';
        return '****-****-****-' . substr($this->nik, -4);
    }

    public function getNik() {
        return $this->nik;
    }

    public function setNamaLengkap($nama) {
        $nama = trim($nama);
        if (!empty($nama)) {
            $this->nama_lengkap = htmlspecialchars($nama);
        }
    }

    public function setNik($nik) {
        $nik = preg_replace('/\D/', '', $nik);
        if (strlen($nik) === 16) {
            $this->nik = $nik;
        } else {
            throw new InvalidArgumentException("NIK harus terdiri dari 16 digit angka.");
        }
    }

    public function setNomorHp($hp) {
        $hp = preg_replace('/\D/', '', $hp);
        if (strlen($hp) >= 10 && strlen($hp) <= 13) {
            $this->nomor_hp = $hp;
        } else {
            throw new InvalidArgumentException("Nomor HP tidak valid.");
        }
    }

    public function setAlamatAsal($alamat) {
        $this->alamat_asal = htmlspecialchars(trim($alamat));
    }

    public function setPlatKendaraan($plat) {
        $this->plat_kendaraan = strtoupper(trim($plat));
    }

    public function getFasilitas() {
        return "Fasilitas standar";
    }

    public function cekStatus() {
        return $this->status === 'terisi' ? 'Terisi' : 'Kosong';
    }

    public function kosongkanKamar() {
        $this->status         = 'kosong';
        $this->nama_lengkap   = null;
        $this->nik            = null;
        $this->nomor_hp       = null;
        $this->alamat_asal    = null;
        $this->plat_kendaraan = null;
    }

    public function simpan($koneksi) {
        $sql  = "INSERT INTO kamar (nomor_kamar, kelas, status, harga_sewa) VALUES (?, ?, ?, ?)";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('sssi', $this->nomor_kamar, $this->kelas, $this->status, $this->harga_sewa);
        $stmt->execute();
        $this->id_kamar = $koneksi->insert_id;
        return $this->id_kamar;
    }

    public function updateStatus($koneksi, $status) {
        $this->setStatus($status);
        $sql  = "UPDATE kamar SET status = ? WHERE id_kamar = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('si', $this->status, $this->id_kamar);
        return $stmt->execute();
    }

    public static function getAll($koneksi) {
        $result = $koneksi->query("SELECT * FROM kamar ORDER BY nomor_kamar ASC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public static function getById($koneksi, $id_kamar) {
        $stmt = $koneksi->prepare("SELECT * FROM kamar WHERE id_kamar = ?");
        $stmt->bind_param('i', $id_kamar);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

}