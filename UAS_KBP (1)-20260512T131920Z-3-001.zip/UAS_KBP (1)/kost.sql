-- ============================================================
-- FILE   : kost.sql
-- DBMS   : MariaDB
-- DESC   : Struktur database untuk Sistem Pendataan Kost
-- TABEL  : kamar, sewa, penghuni, riwayat_penghuni
-- ============================================================

-- Buat database jika belum ada, lalu gunakan
CREATE DATABASE IF NOT EXISTS kost_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE kost_db;

-- ============================================================
-- TABEL 1: kamar
-- Menyimpan data setiap kamar kost
-- ============================================================

CREATE TABLE IF NOT EXISTS kamar (
    id_kamar    INT             NOT NULL AUTO_INCREMENT,
    nomor_kamar VARCHAR(10)     NOT NULL,
    kelas       ENUM('premium', 'eksekutif') NOT NULL,
    status      ENUM('kosong', 'terisi')     NOT NULL DEFAULT 'kosong',
    harga_sewa  INT             NOT NULL DEFAULT 0,
    created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id_kamar),
    UNIQUE KEY uq_nomor_kamar (nomor_kamar)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- TABEL 2: sewa
-- Menyimpan data transaksi sewa per kamar
-- ============================================================

CREATE TABLE IF NOT EXISTS sewa (
    id_sewa        INT  NOT NULL AUTO_INCREMENT,
    id_kamar       INT  NOT NULL,
    tanggal_masuk  DATE NOT NULL,
    durasi_bulan   INT  NOT NULL COMMENT '3, 6, atau 12 bulan',
    tanggal_habis  DATE NOT NULL,
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id_sewa),
    CONSTRAINT fk_sewa_kamar
        FOREIGN KEY (id_kamar) REFERENCES kamar (id_kamar)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- TABEL 3: penghuni
-- Menyimpan data pribadi penghuni yang sedang aktif
-- ============================================================

CREATE TABLE IF NOT EXISTS penghuni (
    id_penghuni    INT          NOT NULL AUTO_INCREMENT,
    id_sewa        INT          NOT NULL,
    nama_lengkap   VARCHAR(100) NOT NULL,
    nik            CHAR(16)     NOT NULL COMMENT '16 digit NIK KTP',
    nomor_hp       VARCHAR(15)  NOT NULL,
    alamat_asal    TEXT         NOT NULL,
    plat_kendaraan VARCHAR(12)           DEFAULT NULL,
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id_penghuni),
    UNIQUE KEY uq_nik (nik),
    CONSTRAINT fk_penghuni_sewa
        FOREIGN KEY (id_sewa) REFERENCES sewa (id_sewa)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- TABEL 4: riwayat_penghuni
-- Menyimpan data penghuni yang sudah checkout
-- (dipindahkan dari tabel penghuni saat proses_checkout.php)
-- ============================================================

CREATE TABLE IF NOT EXISTS riwayat_penghuni (
    id_riwayat     INT          NOT NULL AUTO_INCREMENT,
    id_kamar       INT          NOT NULL,
    nama_lengkap   VARCHAR(100) NOT NULL,
    nik            CHAR(16)     NOT NULL,
    nomor_hp       VARCHAR(15)  NOT NULL,
    alamat_asal    TEXT         NOT NULL,
    plat_kendaraan VARCHAR(12)           DEFAULT NULL,
    tanggal_masuk  DATE         NOT NULL,
    tanggal_keluar DATE         NOT NULL,
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id_riwayat),
    CONSTRAINT fk_riwayat_kamar
        FOREIGN KEY (id_kamar) REFERENCES kamar (id_kamar)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
