<?php

require_once '../koneksi.php';
require_once '../class/Kamar.php';
require_once '../class/TipeKamar.php';
require_once '../class/Sewa.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/kelola_kamar.php');
    exit;
}

$aksi = $_POST['aksi'] ?? 'tambah_kamar';

if ($aksi === 'tambah_kamar') {
    try {
        $nomor_kamar = trim($_POST['nomor_kamar']);
        $kelas       = trim($_POST['kelas']);
        $harga_sewa  = (int) $_POST['harga_sewa'];

        if ($kelas === 'premium') {
            $kamar = new KamarPremium($nomor_kamar, $harga_sewa);
        } elseif ($kelas === 'eksekutif') {
            $kamar = new KamarEksekutif($nomor_kamar, $harga_sewa);
        } else {
            throw new InvalidArgumentException("Kelas kamar tidak valid.");
        }

        $kamar->simpan($koneksi);

        header('Location: ../views/kelola_kamar.php?success=kamar_ditambah');
        exit;

    } catch (Exception $e) {
        header('Location: ../views/kelola_kamar.php?error=' . urlencode($e->getMessage()));
        exit;
    }
}

if ($aksi === 'isi_penghuni') {
    try {
        $id_kamar      = (int) $_POST['id_kamar'];
        $tanggal_masuk = $_POST['tanggal_masuk'];
        $durasi_bulan  = (int) $_POST['durasi_bulan'];

        $sewa    = new Sewa($id_kamar, $tanggal_masuk, $durasi_bulan);
        $id_sewa = $sewa->simpan($koneksi);

        $kamar = new KamarPremium('tmp', 0);
        $kamar->setNamaLengkap($_POST['nama_lengkap']);
        $kamar->setNik($_POST['nik']);
        $kamar->setNomorHp($_POST['nomor_hp']);
        $kamar->setAlamatAsal($_POST['alamat_asal']);
        $kamar->setPlatKendaraan($_POST['plat_kendaraan'] ?? '');

        $nama   = $kamar->getNamaLengkap();
        $nik    = $kamar->getNik();
        $hp     = $kamar->getNomorHp();
        $alamat = $kamar->getAlamatAsal();
        $plat   = $kamar->getPlatKendaraan();

        $sql  = "INSERT INTO penghuni (id_sewa, nama_lengkap, nik, nomor_hp, alamat_asal, plat_kendaraan)
                 VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param('isssss', $id_sewa, $nama, $nik, $hp, $alamat, $plat);
        $stmt->execute();

        $sqlUpdate = "UPDATE kamar SET status = 'terisi' WHERE id_kamar = ?";
        $stmtUp    = $koneksi->prepare($sqlUpdate);
        $stmtUp->bind_param('i', $id_kamar);
        $stmtUp->execute();

        header('Location: ../views/kelola_kamar.php?success=penghuni_ditambah');
        exit;

    } catch (InvalidArgumentException $e) {
        header('Location: ../views/kelola_kamar.php?error=' . urlencode($e->getMessage()));
        exit;
    } catch (Exception $e) {
        header('Location: ../views/kelola_kamar.php?error=' . urlencode('Gagal menyimpan data: ' . $e->getMessage()));
        exit;
    }
}

header('Location: ../views/kelola_kamar.php');
exit;