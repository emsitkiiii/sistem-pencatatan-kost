<?php

require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/kelola_kamar.php');
    exit;
}

try {
    $id_kamar = (int) $_POST['id_kamar'];
    $id_sewa  = (int) $_POST['id_sewa'];

    $stmt = $koneksi->prepare(
        "SELECT p.*, s.tanggal_masuk, s.durasi_bulan, s.tanggal_habis
         FROM penghuni p
         JOIN sewa s ON p.id_sewa = s.id_sewa
         WHERE p.id_sewa = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $id_sewa);
    $stmt->execute();
    $result   = $stmt->get_result();
    $penghuni = $result->fetch_assoc();

    if (!$penghuni) {
        throw new Exception("Data penghuni tidak ditemukan.");
    }

    $sqlRiwayat = "INSERT INTO riwayat_penghuni
                    (id_kamar, nama_lengkap, nik, nomor_hp, alamat_asal,
                     plat_kendaraan, tanggal_masuk, tanggal_keluar)
                   VALUES
                    (?, ?, ?, ?, ?, ?, ?, CURDATE())";

    $stmtRiwayat = $koneksi->prepare($sqlRiwayat);
    $stmtRiwayat->bind_param(
        'issssss',
        $id_kamar,
        $penghuni['nama_lengkap'],
        $penghuni['nik'],
        $penghuni['nomor_hp'],
        $penghuni['alamat_asal'],
        $penghuni['plat_kendaraan'],
        $penghuni['tanggal_masuk']
    );
    $stmtRiwayat->execute();

    $stmtHapusPenghuni = $koneksi->prepare("DELETE FROM penghuni WHERE id_sewa = ?");
    $stmtHapusPenghuni->bind_param('i', $id_sewa);
    $stmtHapusPenghuni->execute();

    $stmtHapusSewa = $koneksi->prepare("DELETE FROM sewa WHERE id_sewa = ?");
    $stmtHapusSewa->bind_param('i', $id_sewa);
    $stmtHapusSewa->execute();

    $stmtKamar = $koneksi->prepare("UPDATE kamar SET status = 'kosong' WHERE id_kamar = ?");
    $stmtKamar->bind_param('i', $id_kamar);
    $stmtKamar->execute();

    header('Location: ../views/kelola_kamar.php?success=checkout');
    exit;

} catch (Exception $e) {
    header('Location: ../views/kelola_kamar.php?error=' . urlencode('Gagal checkout: ' . $e->getMessage()));
    exit;
}