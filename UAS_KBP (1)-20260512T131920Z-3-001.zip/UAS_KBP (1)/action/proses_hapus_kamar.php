<?php

require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/kelola_kamar.php');
    exit;
}

try {
    $id_kamar = (int) $_POST['id_kamar'];

    $cek = $koneksi->prepare("SELECT status FROM kamar WHERE id_kamar = ?");
    $cek->bind_param('i', $id_kamar);
    $cek->execute();
    $result = $cek->get_result();
    $kamar = $result->fetch_assoc();

    if (!$kamar) {
        throw new Exception("Kamar tidak ditemukan.");
    }

    if ($kamar['status'] === 'terisi') {
        throw new Exception("Kamar sedang terisi. Kosongkan terlebih dahulu.");
    }

    // Hapus kamar
    $hapus = $koneksi->prepare("DELETE FROM kamar WHERE id_kamar = ?");
    $hapus->bind_param('i', $id_kamar);

    if (!$hapus->execute()) {
        throw new Exception("Gagal menghapus: " . $hapus->error);
    }

    header('Location: ../views/kelola_kamar.php?success=kamar_dihapus');
    exit;

} catch (Exception $e) {
    header('Location: ../views/kelola_kamar.php?error=' . urlencode($e->getMessage()));
    exit;
}