<?php

require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/kelola_kamar.php');
    exit;
}

try {
    $id_kamar   = (int) $_POST['id_kamar'];
    $nomor_kamar = trim($_POST['nomor_kamar']);
    $kelas      = trim($_POST['kelas']);
    $harga_sewa = (int) $_POST['harga_sewa'];

    if (empty($nomor_kamar)) {
        throw new Exception("Nomor kamar tidak boleh kosong.");
    }

    if (!in_array($kelas, ['premium', 'eksekutif'])) {
        throw new Exception("Kelas kamar tidak valid.");
    }

    if ($harga_sewa < 0) {
        throw new Exception("Harga sewa tidak valid.");
    }

    $cek = $koneksi->prepare("SELECT id_kamar FROM kamar WHERE nomor_kamar = ? AND id_kamar != ?");
    $cek->bind_param('si', $nomor_kamar, $id_kamar);
    $cek->execute();
    $result = $cek->get_result();

    if ($result->num_rows > 0) {
        throw new Exception("Nomor kamar {$nomor_kamar} sudah digunakan.");
    }

    $update = $koneksi->prepare("UPDATE kamar SET nomor_kamar = ?, kelas = ?, harga_sewa = ? WHERE id_kamar = ?");
    $update->bind_param('ssii', $nomor_kamar, $kelas, $harga_sewa, $id_kamar);

    if (!$update->execute()) {
        throw new Exception("Gagal update: " . $update->error);
    }

    header('Location: ../views/kelola_kamar.php?success=kamar_diupdate');
    exit;

} catch (Exception $e) {
    header('Location: ../views/kelola_kamar.php?error=' . urlencode($e->getMessage()));
    exit;
}