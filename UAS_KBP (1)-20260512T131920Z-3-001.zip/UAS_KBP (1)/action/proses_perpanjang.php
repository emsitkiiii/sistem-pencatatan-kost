<?php

require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/kelola_kamar.php');
    exit;
}

try {
    $id_kamar       = (int) $_POST['id_kamar'];
    $id_sewa        = (int) $_POST['id_sewa'];
    $tambahan_bulan = (int) $_POST['tambahan_bulan'];

    $allowed = [3, 6, 12];
    if (!in_array($tambahan_bulan, $allowed)) {
        throw new Exception("Tambahan durasi harus 3, 6, atau 12 bulan.");
    }

    $stmt = $koneksi->prepare("SELECT * FROM sewa WHERE id_sewa = ?");
    $stmt->bind_param('i', $id_sewa);
    $stmt->execute();
    $result = $stmt->get_result();
    $data_sewa = $result->fetch_assoc();

    if (!$data_sewa) {
        throw new Exception("Data sewa tidak ditemukan.");
    }

    $tanggal_habis_baru = date('Y-m-d', strtotime($data_sewa['tanggal_habis'] . " +{$tambahan_bulan} months"));
    $durasi_baru = (int) $data_sewa['durasi_bulan'] + $tambahan_bulan;

    $update = $koneksi->prepare("UPDATE sewa SET tanggal_habis = ?, durasi_bulan = ? WHERE id_sewa = ?");
    $update->bind_param('sii', $tanggal_habis_baru, $durasi_baru, $id_sewa);
    
    if (!$update->execute()) {
        throw new Exception("Gagal update: " . $update->error);
    }

    header('Location: ../views/kelola_kamar.php?success=diperpanjang');
    exit;

} catch (Exception $e) {
    header('Location: ../views/kelola_kamar.php?error=' . urlencode($e->getMessage()));
    exit;
}